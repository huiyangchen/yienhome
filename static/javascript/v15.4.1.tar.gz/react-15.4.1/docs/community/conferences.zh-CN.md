---
id: conferences-zh-CN
title: 会议
permalink: docs/conferences-zh-CN.html
prev: thinking-in-react-zh-CN.html
next: videos-zh-CN.html
---

### React.js Conf 2015
一月 28 & 29

[Website](http://conf.reactjs.com/) - [Schedule](http://conf.reactjs.com/schedule.html) - [Videos](https://www.youtube-nocookie.com/playlist?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr)

<iframe width="100%" height="315" src="//www.youtube-nocookie.com/embed/KVZ-P-ZI6W4?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr" frameborder="0" allowfullscreen></iframe>

### ReactEurope 2015
七月 2 & 3

[Website](http://www.react-europe.org/) - [Schedule](http://www.react-europe.org/#schedule)

### Reactive 2015
十一月 2-4

[Website](https://reactive2015.com/) - [Schedule](https://reactive2015.com/schedule_speakers.html#schedule)

### ReactEurope 2016
六月 2 & 3

[Website](http://www.react-europe.org/) - [Schedule](http://www.react-europe.org/#schedule)
